package com.stire.runner;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.io.File;
import java.io.InputStream;
import java.util.Random;

public class LucinaSounds {

    protected Media attack;
    protected Media hope;
    protected Media ready;
    protected Media take;
    protected Media now;

    protected MediaPlayer player;

    public LucinaSounds() {
        this.attack = new Media(new File(".\\sounds\\lucina\\Attack.wav").toURI().toString());
        this.player = new MediaPlayer(null);
    }

    public void attack(){
        Random r = new Random();
        if (r.nextFloat()<0.1){
            player = new MediaPlayer(take);
        }
        else {
            player = new MediaPlayer(attack);
        }
        player.play();
    }

    public void start(){
        Random r = new Random();
        if (r.nextFloat()<0.5){
            player = new MediaPlayer(ready);
        }
        else {
            player = new MediaPlayer(now);
        }
        player.play();
    }

    public void stop(){
        player = new MediaPlayer(hope);
        player.play();
    }
}

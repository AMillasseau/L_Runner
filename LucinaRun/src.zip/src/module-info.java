module com.stire.runner {
    requires javafx.graphics;
    requires javafx.media;
    requires javafx.controls;

}